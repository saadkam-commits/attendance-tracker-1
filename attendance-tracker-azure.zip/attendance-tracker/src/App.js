// src/App.js
import { useState } from "react";
import AccessScreen from "./AccessScreen";
import AttendanceTracker from "./AttendanceTracker";

export default function App() {
  const [session, setSession] = useState(null);

  if (!session) return <AccessScreen onEnter={setSession} />;

  return (
    <AttendanceTracker
      clientId={session.clientId}
      clientName={session.clientName}
      userName={session.userName}
      isAdmin={session.isAdmin}
      accessCode={session.accessCode || ""}
      onLogout={() => setSession(null)}
    />
  );
}
