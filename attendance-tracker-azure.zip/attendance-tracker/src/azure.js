// src/azure.js
// -------------------------------------------------------
// SETUP INSTRUCTIONS:
// 1. Go to https://portal.azure.com (sign in with your Outlook account)
// 2. Search "Azure Cosmos DB" → Create → Choose "Azure Cosmos DB for NoSQL"
// 3. Fill in:
//    - Subscription: your subscription (Free tier works)
//    - Resource Group: Create new → "attendance-tracker-rg"
//    - Account Name: "attendance-tracker-db" (must be globally unique)
//    - Capacity mode: Serverless (free-tier friendly)
// 4. Review + Create → wait ~5 mins for deployment
// 5. Go to your Cosmos DB resource → Data Explorer
//    - Create Database: "AttendanceDB"
//    - Create Containers: "clients", "attendance", "members"
//    - Partition key for all: "/id"
// 6. Go to Keys → copy PRIMARY CONNECTION STRING
// 7. Paste values into .env file (see .env.example)
// -------------------------------------------------------

// Azure Cosmos DB client config — values come from .env
export const AZURE_CONFIG = {
  endpoint: process.env.REACT_APP_COSMOS_ENDPOINT,
  key: process.env.REACT_APP_COSMOS_KEY,
  databaseId: "AttendanceDB",
  containers: {
    clients: "clients",
    attendance: "attendance",
    members: "members",
  }
};

// Base API helper — calls your Azure Static Web App API routes
// which proxy to Cosmos DB securely (keys never exposed to browser)
export async function azureApi(method, path, body = null) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : null,
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(err || "API error");
  }
  return res.json();
}
