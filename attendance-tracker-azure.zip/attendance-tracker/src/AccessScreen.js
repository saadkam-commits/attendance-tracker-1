// src/AccessScreen.js
import { useState } from "react";

const S = {
  wrap: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #0f172a 100%)", padding: 24, position: "relative", overflow: "hidden" },
  glow: { position: "absolute", width: 600, height: 600, borderRadius: "50%", background: "radial-gradient(circle, rgba(14,165,233,0.07) 0%, transparent 70%)", top: "50%", left: "50%", transform: "translate(-50%, -50%)", pointerEvents: "none" },
  card: { background: "rgba(255,255,255,0.03)", backdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: "48px 40px", width: "100%", maxWidth: 420, position: "relative" },
  logo: { width: 52, height: 52, borderRadius: 14, background: "linear-gradient(135deg, #0ea5e9, #0369a1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, marginBottom: 20 },
  msTag: { display: "inline-flex", alignItems: "center", gap: 5, fontSize: 11, color: "#0ea5e9", background: "rgba(14,165,233,0.08)", border: "1px solid rgba(14,165,233,0.15)", borderRadius: 6, padding: "3px 8px", marginBottom: 18 },
  title: { fontFamily: "'Syne', sans-serif", fontSize: 26, fontWeight: 800, marginBottom: 5, letterSpacing: "-0.5px" },
  sub: { fontSize: 13, color: "#64748b", marginBottom: 32 },
  label: { fontSize: 11, fontWeight: 700, color: "#64748b", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 7, display: "block" },
  input: { width: "100%", padding: "12px 16px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.09)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 14, outline: "none", marginBottom: 14, fontFamily: "'DM Sans', sans-serif" },
  codeInput: { width: "100%", padding: "12px 16px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.09)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 18, outline: "none", marginBottom: 14, fontFamily: "'DM Mono', monospace", letterSpacing: "0.2em", textTransform: "uppercase" },
  btn: { width: "100%", padding: "13px", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #0ea5e9, #0369a1)", color: "#fff", fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15, cursor: "pointer", marginTop: 4 },
  divider: { display: "flex", alignItems: "center", gap: 12, margin: "24px 0", color: "#334155", fontSize: 12 },
  line: { flex: 1, height: 1, background: "rgba(255,255,255,0.06)" },
  ghostBtn: { width: "100%", padding: "12px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.08)", background: "transparent", color: "#64748b", fontFamily: "'Syne', sans-serif", fontWeight: 600, fontSize: 13, cursor: "pointer" },
  error: { background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.18)", borderRadius: 8, padding: "10px 14px", fontSize: 13, color: "#fca5a5", marginBottom: 14 },
  success: { background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.18)", borderRadius: 8, padding: "12px 16px", fontSize: 13, color: "#6ee7b7", marginBottom: 14, lineHeight: 1.7 },
};

export default function AccessScreen({ onEnter }) {
  const [mode, setMode] = useState("join");
  const [code, setCode] = useState("");
  const [clientName, setClientName] = useState("");
  const [yourName, setYourName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [newCode, setNewCode] = useState("");

  const handleJoin = async () => {
    if (!code.trim() || !yourName.trim()) { setError("Please enter both your name and the access code."); return; }
    setLoading(true); setError("");
    try {
      const res = await fetch(`/api/clients?code=${code.trim().toUpperCase()}`);
      if (res.status === 404) { setError("Invalid access code. Please check with your admin."); setLoading(false); return; }
      if (!res.ok) throw new Error();
      const client = await res.json();
      await fetch("/api/members", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clientId: client.id, name: yourName.trim() }) });
      onEnter({ clientId: client.id, clientName: client.name, userName: yourName.trim(), isAdmin: false, accessCode: client.code });
    } catch { setError("Connection error. Ensure the app is deployed on Azure Static Web Apps."); }
    setLoading(false);
  };

  const handleCreate = async () => {
    if (!clientName.trim() || !yourName.trim()) { setError("Please fill in all fields."); return; }
    setLoading(true); setError("");
    try {
      const res = await fetch("/api/clients", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: clientName.trim(), adminName: yourName.trim() }) });
      if (!res.ok) throw new Error();
      const client = await res.json();
      setNewCode(client.code);
      setTimeout(() => onEnter({ clientId: client.id, clientName: client.name, userName: yourName.trim(), isAdmin: true, accessCode: client.code }), 2500);
    } catch { setError("Failed to create workspace. Check your Azure configuration."); }
    setLoading(false);
  };

  return (
    <div style={S.wrap}>
      <div style={S.glow} />
      <div style={S.card}>
        <div style={S.logo}>📋</div>
        <div style={S.msTag}>☁️ Powered by Microsoft Azure</div>
        <div style={S.title}>Attendance Tracker</div>
        <div style={S.sub}>Onsite Resource Management</div>
        {error && <div style={S.error}>⚠️ {error}</div>}
        {newCode && <div style={S.success}>✅ Workspace created!<br />Share this code with your team:<br /><span style={{ fontFamily: "'DM Mono', monospace", fontSize: 22, letterSpacing: "0.2em" }}>{newCode}</span><br /><span style={{ fontSize: 11, opacity: 0.7 }}>Entering workspace...</span></div>}
        {mode === "join" ? (
          <>
            <label style={S.label}>Your Name</label>
            <input style={S.input} placeholder="e.g. Ahmed Khan" value={yourName} onChange={e => setYourName(e.target.value)} onKeyDown={e => e.key === "Enter" && handleJoin()} />
            <label style={S.label}>Access Code</label>
            <input style={S.codeInput} placeholder="XXXXXXXX" value={code} onChange={e => setCode(e.target.value)} maxLength={10} onKeyDown={e => e.key === "Enter" && handleJoin()} />
            <button style={S.btn} onClick={handleJoin} disabled={loading}>{loading ? "Verifying..." : "Enter Workspace →"}</button>
            <div style={S.divider}><div style={S.line} /><span>or</span><div style={S.line} /></div>
            <button style={S.ghostBtn} onClick={() => { setMode("create"); setError(""); }}>+ Create new client workspace</button>
          </>
        ) : (
          <>
            <label style={S.label}>Client / Project Name</label>
            <input style={S.input} placeholder="e.g. Project Alpha" value={clientName} onChange={e => setClientName(e.target.value)} />
            <label style={S.label}>Your Name (Admin)</label>
            <input style={S.input} placeholder="e.g. Sara Malik" value={yourName} onChange={e => setYourName(e.target.value)} onKeyDown={e => e.key === "Enter" && handleCreate()} />
            <button style={S.btn} onClick={handleCreate} disabled={loading}>{loading ? "Creating..." : "Create Workspace →"}</button>
            <div style={S.divider}><div style={S.line} /><span>or</span><div style={S.line} /></div>
            <button style={S.ghostBtn} onClick={() => { setMode("join"); setError(""); }}>← Join with existing code</button>
          </>
        )}
      </div>
    </div>
  );
}
