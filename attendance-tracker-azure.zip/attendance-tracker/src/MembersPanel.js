// src/MembersPanel.js
import { useState, useEffect } from "react";

const S = {
  overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(4px)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 },
  panel: { background: "#1e293b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: 32, width: "100%", maxWidth: 460, maxHeight: "80vh", display: "flex", flexDirection: "column" },
  header: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 22 },
  title: { fontFamily: "'Syne', sans-serif", fontSize: 19, fontWeight: 800 },
  closeBtn: { background: "none", border: "none", color: "#64748b", fontSize: 22, cursor: "pointer" },
  codeBox: { background: "rgba(14,165,233,0.07)", border: "1px solid rgba(14,165,233,0.18)", borderRadius: 10, padding: "14px 16px", marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "space-between" },
  codeLabel: { fontSize: 11, color: "#38bdf8", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 4 },
  codeVal: { fontFamily: "'DM Mono', monospace", fontSize: 20, letterSpacing: "0.18em", color: "#7dd3fc" },
  copyBtn: { background: "rgba(14,165,233,0.15)", border: "none", color: "#38bdf8", borderRadius: 6, padding: "6px 14px", fontSize: 12, cursor: "pointer", fontWeight: 700 },
  hint: { fontSize: 12, color: "#475569", marginBottom: 16 },
  membersList: { flex: 1, overflowY: "auto", marginBottom: 18 },
  memberRow: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 13px", borderRadius: 8, marginBottom: 5, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.05)" },
  memberName: { fontSize: 14, fontWeight: 500 },
  memberMeta: { fontSize: 11, color: "#475569", marginTop: 2 },
  removeBtn: { background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 15, opacity: 0.45, padding: "2px 6px" },
  addRow: { display: "flex", gap: 10 },
  input: { flex: 1, padding: "10px 13px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 14, outline: "none" },
  addBtn: { padding: "10px 18px", borderRadius: 8, border: "none", background: "linear-gradient(135deg, #0ea5e9, #0369a1)", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" },
  badge: { fontSize: 10, padding: "2px 7px", borderRadius: 99, background: "rgba(14,165,233,0.12)", color: "#38bdf8", fontWeight: 700, marginLeft: 7 },
  youBadge: { fontSize: 10, padding: "2px 7px", borderRadius: 99, background: "rgba(16,185,129,0.12)", color: "#34d399", fontWeight: 700, marginLeft: 7 },
};

export default function MembersPanel({ clientId, clientName, accessCode, userName, onClose }) {
  const [members, setMembers] = useState([]);
  const [newMember, setNewMember] = useState("");
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchMembers = async () => {
    try {
      const res = await fetch(`/api/members?clientId=${clientId}`);
      const data = await res.json();
      setMembers(data);
    } catch { /* silent */ }
    setLoading(false);
  };

  useEffect(() => { fetchMembers(); }, [clientId]);

  const addMember = async () => {
    const name = newMember.trim();
    if (!name) return;
    try {
      await fetch("/api/members", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clientId, name }) });
      setNewMember("");
      fetchMembers();
    } catch { /* silent */ }
  };

  const removeMember = async (memberId) => {
    try {
      await fetch(`/api/members?memberId=${memberId}`, { method: "DELETE" });
      setMembers(m => m.filter(x => x.id !== memberId));
    } catch { /* silent */ }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(accessCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={S.overlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={S.panel}>
        <div style={S.header}>
          <div style={S.title}>👥 Team Members</div>
          <button style={S.closeBtn} onClick={onClose}>×</button>
        </div>
        <div style={S.codeBox}>
          <div>
            <div style={S.codeLabel}>Workspace Access Code</div>
            <div style={S.codeVal}>{accessCode}</div>
          </div>
          <button style={S.copyBtn} onClick={copyCode}>{copied ? "✓ Copied!" : "Copy"}</button>
        </div>
        <div style={S.hint}>Share this code so team members can join <b style={{ color: "#94a3b8" }}>{clientName}</b></div>
        <div style={S.membersList}>
          {loading && <div style={{ color: "#334155", textAlign: "center", padding: 24, fontSize: 13 }}>Loading...</div>}
          {!loading && members.length === 0 && <div style={{ color: "#334155", textAlign: "center", padding: 24, fontSize: 13 }}>No members yet.</div>}
          {members.map(m => (
            <div key={m.id} style={S.memberRow}>
              <div>
                <div style={S.memberName}>
                  {m.name}
                  {m.isAdmin && <span style={S.badge}>Admin</span>}
                  {m.name === userName && <span style={S.youBadge}>You</span>}
                </div>
                <div style={S.memberMeta}>{m.joinedAt ? `Joined ${new Date(m.joinedAt).toLocaleDateString()}` : "Recently joined"}</div>
              </div>
              {m.name !== userName && <button style={S.removeBtn} onClick={() => removeMember(m.id)} title="Remove">×</button>}
            </div>
          ))}
        </div>
        <div style={S.addRow}>
          <input style={S.input} placeholder="Add member by name..." value={newMember} onChange={e => setNewMember(e.target.value)} onKeyDown={e => e.key === "Enter" && addMember()} />
          <button style={S.addBtn} onClick={addMember}>+ Add</button>
        </div>
      </div>
    </div>
  );
}
