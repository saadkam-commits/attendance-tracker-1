// src/AttendanceTracker.js
import { useState, useEffect, useCallback, useRef } from "react";
import MembersPanel from "./MembersPanel";

const STATUS_LABELS = { P: "Present", A: "Absent", L: "Leave", WFH: "Work From Home" };
const STATUS_COLORS = {
  P:   { bg: "#d1fae5", text: "#065f46", border: "#6ee7b7" },
  A:   { bg: "#fee2e2", text: "#991b1b", border: "#fca5a5" },
  L:   { bg: "#dcfce7", text: "#166534", border: "#86efac" },
  WFH: { bg: "#fef9c3", text: "#854d0e", border: "#fde047" },
  "":  { bg: "rgba(255,255,255,0.04)", text: "#334155", border: "rgba(255,255,255,0.08)" },
};
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DAYS_IN_MONTH = (y, m) => new Date(y, m + 1, 0).getDate();
const DAY_NAME = (y, m, d) => ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][new Date(y, m, d).getDay()];
const IS_WEEKEND = (y, m, d) => { const day = new Date(y, m, d).getDay(); return day === 0 || day === 6; };

export default function AttendanceTracker({ clientId, clientName, userName, isAdmin, accessCode, onLogout }) {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState({});
  const [activeTab, setActiveTab] = useState("grid");
  const [showMembers, setShowMembers] = useState(false);
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);
  const [newName, setNewName] = useState("");
  const [showAddEmp, setShowAddEmp] = useState(false);
  const saveTimer = useRef(null);

  const monthKey = `${year}-${String(month + 1).padStart(2, "0")}`;
  const daysCount = DAYS_IN_MONTH(year, month);
  const days = Array.from({ length: daysCount }, (_, i) => i + 1);
  const workingDays = days.filter(d => !IS_WEEKEND(year, month, d)).length;

  // Fetch employees
  const fetchEmployees = useCallback(async () => {
    try {
      const res = await fetch(`/api/employees?clientId=${clientId}`);
      if (res.ok) { const data = await res.json(); setEmployees(data.list || []); }
    } catch { /* silent */ }
  }, [clientId]);

  // Fetch attendance
  const fetchAttendance = useCallback(async () => {
    try {
      const res = await fetch(`/api/attendance?clientId=${clientId}&monthKey=${monthKey}`);
      if (res.ok) { const data = await res.json(); setAttendance(data.records || {}); }
    } catch { /* silent */ }
  }, [clientId, monthKey]);

  // Poll every 15 seconds for real-time sync
  useEffect(() => {
    fetchEmployees();
    const interval = setInterval(fetchEmployees, 15000);
    return () => clearInterval(interval);
  }, [fetchEmployees]);

  useEffect(() => {
    fetchAttendance();
    const interval = setInterval(fetchAttendance, 15000);
    return () => clearInterval(interval);
  }, [fetchAttendance]);

  const saveEmployees = async (list) => {
    setSaving(true);
    try {
      await fetch("/api/employees", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clientId, list }) });
      setLastSaved(new Date());
    } catch { /* silent */ }
    setSaving(false);
  };

  const saveAttendance = async (records) => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      setSaving(true);
      try {
        await fetch("/api/attendance", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clientId, monthKey, records, updatedBy: userName }) });
        setLastSaved(new Date());
      } catch { /* silent */ }
      setSaving(false);
    }, 600); // debounce rapid clicks
  };

  const getStatus = (emp, day) => attendance[`${emp}__${day}`] || "";

  const cycleStatus = (emp, day) => {
    const cur = getStatus(emp, day);
    const next = cur === "" ? "P" : cur === "P" ? "A" : cur === "A" ? "L" : cur === "L" ? "WFH" : "";
    const newRecords = { ...attendance, [`${emp}__${day}`]: next };
    setAttendance(newRecords);
    saveAttendance(newRecords);
  };

  const addEmployee = async () => {
    const name = newName.trim();
    if (!name || employees.includes(name)) return;
    const newList = [...employees, name];
    setEmployees(newList);
    await saveEmployees(newList);
    setNewName(""); setShowAddEmp(false);
  };

  const removeEmployee = async (name) => {
    const newList = employees.filter(e => e !== name);
    setEmployees(newList);
    await saveEmployees(newList);
  };

  const navigateMonth = (dir) => {
    let m = month + dir, y = year;
    if (m > 11) { m = 0; y++; }
    if (m < 0) { m = 11; y--; }
    setMonth(m); setYear(y);
  };

  const getSummary = (emp) => {
    const counts = { P: 0, A: 0, L: 0, WFH: 0, "": 0 };
    days.forEach(d => { if (!IS_WEEKEND(year, month, d)) counts[getStatus(emp, d)]++; });
    return counts;
  };

  const exportCSV = () => {
    const header = ["Employee", ...days.map(d => `${d} ${DAY_NAME(year, month, d)}`), "P", "A", "L", "WFH", "Unmarked"];
    const rows = employees.map(emp => {
      const s = getSummary(emp);
      return [emp, ...days.map(d => getStatus(emp, d) || "-"), s.P, s.A, s.L, s.WFH, s[""]];
    });
    const csv = [header, ...rows].map(r => r.map(c => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    a.download = `Attendance_${clientName}_${year}_${MONTHS[month]}.csv`; a.click();
  };

  const printPDF = () => {
    const win = window.open("", "_blank");
    const tableRows = employees.map(emp => {
      const s = getSummary(emp);
      const cells = days.map(d => {
        const st = getStatus(emp, d); const isWknd = IS_WEEKEND(year, month, d);
        return `<td style="background:${isWknd?"#e5e7eb":st?STATUS_COLORS[st].bg:"#fff"};color:${isWknd?"#9ca3af":st?STATUS_COLORS[st].text:"#374151"};text-align:center;padding:4px 2px;font-size:10px;border:1px solid #e5e7eb">${isWknd?"—":(st||"")}</td>`;
      }).join("");
      return `<tr><td style="padding:5px 10px;border:1px solid #e5e7eb;font-weight:600;white-space:nowrap;font-size:11px">${emp}</td>${cells}<td style="padding:4px;border:1px solid #e5e7eb;text-align:center;background:#d1fae5;font-size:10px">${s.P}</td><td style="padding:4px;border:1px solid #e5e7eb;text-align:center;background:#fee2e2;font-size:10px">${s.A}</td><td style="padding:4px;border:1px solid #e5e7eb;text-align:center;background:#dcfce7;font-size:10px">${s.L}</td><td style="padding:4px;border:1px solid #e5e7eb;text-align:center;background:#fef9c3;font-size:10px">${s.WFH}</td></tr>`;
    }).join("");
    const dayHeaders = days.map(d => { const w = IS_WEEKEND(year,month,d); return `<th style="padding:4px 2px;border:1px solid #e5e7eb;background:${w?"#f3f4f6":"#1e3a5f"};color:${w?"#9ca3af":"#fff"};min-width:26px;font-size:9px;text-align:center">${d}<br/>${DAY_NAME(year,month,d)}</th>`; }).join("");
    win.document.write(`<!DOCTYPE html><html><head><title>Attendance - ${clientName} - ${MONTHS[month]} ${year}</title><style>@page{margin:12mm;size:A3 landscape}body{font-family:'Segoe UI',sans-serif;color:#1f2937}h1{color:#1e3a5f;font-size:18px;margin-bottom:3px}p{color:#6b7280;font-size:11px;margin:0 0 14px}table{border-collapse:collapse;width:100%}.leg{display:flex;gap:14px;margin-bottom:10px;font-size:10px;flex-wrap:wrap}.li{display:flex;align-items:center;gap:4px}.lb{width:12px;height:12px;border-radius:2px;border:1px solid #e5e7eb}</style></head><body><h1>Attendance Register — ${clientName}</h1><p>${MONTHS[month]} ${year} · Generated: ${new Date().toLocaleDateString()} · ${workingDays} working days</p><div class="leg"><div class="li"><div class="lb" style="background:#d1fae5"></div>Present</div><div class="li"><div class="lb" style="background:#fee2e2"></div>Absent</div><div class="li"><div class="lb" style="background:#dcfce7"></div>Leave</div><div class="li"><div class="lb" style="background:#fef9c3"></div>WFH</div></div><table><thead><tr><th style="padding:6px 10px;border:1px solid #e5e7eb;background:#1e3a5f;color:#fff;text-align:left;font-size:11px">Employee</th>${dayHeaders}<th style="padding:4px;border:1px solid #e5e7eb;background:#065f46;color:#fff;font-size:9px">P</th><th style="padding:4px;border:1px solid #e5e7eb;background:#991b1b;color:#fff;font-size:9px">A</th><th style="padding:4px;border:1px solid #e5e7eb;background:#14532d;color:#fff;font-size:9px">L</th><th style="padding:4px;border:1px solid #e5e7eb;background:#78350f;color:#fff;font-size:9px">WFH</th></tr></thead><tbody>${tableRows}</tbody></table></body></html>`);
    win.document.close(); setTimeout(() => win.print(), 400);
  };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg, #0f172a 0%, #1e293b 100%)", fontFamily: "'DM Sans', sans-serif", color: "#f1f5f9" }}>
      {/* Header */}
      <div style={{ background: "rgba(255,255,255,0.03)", borderBottom: "1px solid rgba(255,255,255,0.07)", padding: "15px 26px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: "linear-gradient(135deg, #0ea5e9, #0369a1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>📋</div>
          <div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 16, fontWeight: 800, letterSpacing: "-0.3px" }}>Attendance Tracker</div>
            <div style={{ fontSize: 11, color: "#475569" }}>
              <span style={{ color: "#38bdf8", fontWeight: 600 }}>{clientName}</span>
              <span style={{ margin: "0 5px" }}>·</span>
              <span>{userName}</span>
              {saving && <span style={{ marginLeft: 8, color: "#f59e0b", fontSize: 10 }}>⟳ Saving...</span>}
              {!saving && lastSaved && <span style={{ marginLeft: 8, color: "#34d399", fontSize: 10 }}>✓ Saved {lastSaved.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>}
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
          <button onClick={() => setShowMembers(true)} style={btn("#1e3a5f")}>👥 Team</button>
          <button onClick={exportCSV} style={btn("#4c1d95")}>📊 Excel</button>
          <button onClick={printPDF} style={btn("#78350f")}>🖨️ PDF</button>
          <button onClick={onLogout} style={btn("#1e293b", "#64748b")}>← Switch</button>
        </div>
      </div>

      <div style={{ padding: "18px 26px" }}>
        {/* Month Nav */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 18, flexWrap: "wrap" }}>
          <button onClick={() => navigateMonth(-1)} style={navBtn()}>‹</button>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 800, letterSpacing: "-0.8px", minWidth: 200, textAlign: "center" }}>
            {MONTHS[month]} <span style={{ color: "#0ea5e9" }}>{year}</span>
          </div>
          <button onClick={() => navigateMonth(1)} style={navBtn()}>›</button>
          <div style={{ marginLeft: "auto", display: "flex", gap: 18, fontSize: 12, color: "#475569" }}>
            <span>👥 <b style={{ color: "#e2e8f0" }}>{employees.length}</b></span>
            <span>📅 <b style={{ color: "#e2e8f0" }}>{workingDays}</b> days</span>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginBottom: 14 }}>
          {[["grid","📅 Grid"],["summary","📊 Summary"]].map(([t,label]) => (
            <button key={t} onClick={() => setActiveTab(t)} style={{ padding: "6px 16px", borderRadius: 7, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 12, background: activeTab === t ? "#0ea5e9" : "rgba(255,255,255,0.05)", color: activeTab === t ? "#fff" : "#64748b", transition: "all 0.2s" }}>{label}</button>
          ))}
        </div>

        {/* Legend */}
        <div style={{ display: "flex", gap: 10, marginBottom: 12, flexWrap: "wrap", alignItems: "center" }}>
          {Object.entries(STATUS_LABELS).map(([k, v]) => (
            <div key={k} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11 }}>
              <div style={{ width: 19, height: 19, borderRadius: 4, background: STATUS_COLORS[k].bg, border: `1px solid ${STATUS_COLORS[k].border}`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, color: STATUS_COLORS[k].text, fontSize: 9 }}>{k}</div>
              <span style={{ color: "#475569" }}>{v}</span>
            </div>
          ))}
          <span style={{ color: "#334155", fontSize: 11, marginLeft: 4 }}>· Click to cycle</span>
        </div>

        {/* Grid */}
        {activeTab === "grid" && (
          <div style={{ overflowX: "auto", borderRadius: 10, border: "1px solid rgba(255,255,255,0.07)" }}>
            <table style={{ borderCollapse: "collapse", width: "100%", minWidth: 800 }}>
              <thead>
                <tr>
                  <th style={th(true, false)}>Employee</th>
                  {days.map(d => (
                    <th key={d} style={{ ...th(true, IS_WEEKEND(year, month, d)), fontSize: 9, padding: "5px 1px", minWidth: 32 }}>
                      <div>{d}</div><div style={{ fontWeight: 400, opacity: 0.6, fontSize: 8 }}>{DAY_NAME(year, month, d)}</div>
                    </th>
                  ))}
                  {["P","A","L","WFH","–"].map((h,i) => (
                    <th key={h} style={{ ...th(true,false), background: ["#065f46","#7f1d1d","#14532d","#78350f","#1e293b"][i], fontSize: 9, padding: "4px 4px" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {employees.length === 0 ? (
                  <tr><td colSpan={days.length + 6} style={{ textAlign: "center", padding: 44, color: "#334155", fontSize: 13 }}>No resources added yet.</td></tr>
                ) : employees.map((emp, ei) => {
                  const s = getSummary(emp);
                  return (
                    <tr key={emp} style={{ background: ei % 2 === 0 ? "rgba(255,255,255,0.015)" : "transparent" }}>
                      <td style={{ padding: "7px 11px", borderRight: "1px solid rgba(255,255,255,0.06)", borderBottom: "1px solid rgba(255,255,255,0.04)", fontWeight: 600, fontSize: 12, whiteSpace: "nowrap", minWidth: 125 }}>
                        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 5 }}>
                          <span>{emp}</span>
                          <button onClick={() => removeEmployee(emp)} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 13, opacity: 0.35, padding: "0 2px" }}>×</button>
                        </div>
                      </td>
                      {days.map(d => {
                        const st = getStatus(emp, d); const isWknd = IS_WEEKEND(year, month, d);
                        return (
                          <td key={d} onClick={isWknd ? undefined : () => cycleStatus(emp, d)}
                            style={{ textAlign: "center", padding: "4px 1px", border: "1px solid rgba(255,255,255,0.03)", cursor: isWknd ? "default" : "pointer", userSelect: "none" }}>
                            <div style={{ margin: "0 auto", width: 26, height: 22, borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 9, background: isWknd ? "rgba(255,255,255,0.02)" : STATUS_COLORS[st].bg, color: isWknd ? "#1e293b" : STATUS_COLORS[st].text, border: isWknd ? "1px solid rgba(255,255,255,0.03)" : `1px solid ${STATUS_COLORS[st].border}` }}>
                              {isWknd ? "—" : (st || "")}
                            </div>
                          </td>
                        );
                      })}
                      {[s.P,s.A,s.L,s.WFH,s[""]].map((val,i) => (
                        <td key={i} style={{ textAlign: "center", padding: "4px", border: "1px solid rgba(255,255,255,0.03)", fontWeight: 700, fontSize: 11, background: ["#065f4620","#7f1d1d20","#14532d20","#78350f20","#1e293b40"][i], color: "#cbd5e1" }}>{val}</td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Summary */}
        {activeTab === "summary" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: 12 }}>
            {employees.length === 0 ? <div style={{ color: "#334155", textAlign: "center", padding: 44, gridColumn: "1/-1" }}>No resources added yet.</div>
              : employees.map(emp => {
                const s = getSummary(emp);
                const pct = workingDays > 0 ? Math.round((s.P / workingDays) * 100) : 0;
                return (
                  <div key={emp} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: 16 }}>
                    <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 3 }}>{emp}</div>
                    <div style={{ fontSize: 11, color: "#475569", marginBottom: 12 }}>{MONTHS[month]} {year}</div>
                    <div style={{ display: "flex", gap: 5, marginBottom: 12 }}>
                      {[["P","Present",s.P,"#d1fae5","#065f46"],["A","Absent",s.A,"#fee2e2","#991b1b"],["L","Leave",s.L,"#dcfce7","#166534"],["WFH","WFH",s.WFH,"#fef9c3","#854d0e"]].map(([k,label,val,bg,fg]) => (
                        <div key={k} style={{ flex: 1, background: bg, borderRadius: 7, padding: "6px 3px", textAlign: "center" }}>
                          <div style={{ fontWeight: 800, fontSize: 17, color: fg }}>{val}</div>
                          <div style={{ fontSize: 9, color: fg, opacity: 0.8 }}>{label}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{ fontSize: 11, color: "#475569", marginBottom: 4 }}>Attendance Rate</div>
                    <div style={{ height: 5, background: "rgba(255,255,255,0.07)", borderRadius: 99, overflow: "hidden" }}>
                      <div style={{ height: "100%", width: `${pct}%`, background: pct >= 80 ? "#10b981" : pct >= 60 ? "#f59e0b" : "#ef4444", borderRadius: 99, transition: "width 0.4s" }} />
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 700, marginTop: 5, color: pct >= 80 ? "#34d399" : pct >= 60 ? "#fbbf24" : "#f87171" }}>{pct}%</div>
                  </div>
                );
              })}
          </div>
        )}

        {/* Add Employee */}
        <div style={{ marginTop: 18 }}>
          {showAddEmp ? (
            <div style={{ display: "flex", gap: 8, maxWidth: 360 }}>
              <input value={newName} onChange={e => setNewName(e.target.value)} onKeyDown={e => e.key === "Enter" && addEmployee()} placeholder="Full name..." autoFocus
                style={{ flex: 1, padding: "9px 12px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 13, outline: "none" }} />
              <button onClick={addEmployee} style={btn("#065f46")}>Add</button>
              <button onClick={() => { setShowAddEmp(false); setNewName(""); }} style={btn("#1e293b", "#64748b")}>Cancel</button>
            </div>
          ) : (
            <button onClick={() => setShowAddEmp(true)} style={btn("#1e3a5f")}>+ Add Resource</button>
          )}
        </div>
      </div>

      {showMembers && <MembersPanel clientId={clientId} clientName={clientName} accessCode={accessCode} userName={userName} onClose={() => setShowMembers(false)} />}
    </div>
  );
}

const btn = (bg, color = "#fff") => ({ padding: "7px 14px", borderRadius: 7, border: "none", background: bg, color, cursor: "pointer", fontSize: 12, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 4, whiteSpace: "nowrap" });
const navBtn = () => ({ width: 34, height: 34, borderRadius: 7, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.04)", color: "#f1f5f9", cursor: "pointer", fontSize: 18, display: "flex", alignItems: "center", justifyContent: "center" });
const th = (isHdr, isWknd) => ({ padding: "8px 4px", borderBottom: "1px solid rgba(255,255,255,0.07)", borderRight: "1px solid rgba(255,255,255,0.05)", background: isWknd ? "rgba(255,255,255,0.01)" : isHdr ? "#1e3a5f" : "transparent", color: isWknd ? "#1e293b" : "#e2e8f0", fontWeight: 700, fontSize: 11, textAlign: "center", whiteSpace: "nowrap" });
