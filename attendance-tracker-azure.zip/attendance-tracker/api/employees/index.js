// api/employees/index.js
// GET  /api/employees?clientId=X
// POST /api/employees  { clientId, list: [...] }
const { clients } = require("../shared/cosmosClient");

module.exports = async function (context, req) {
  context.res = { headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } };
  try {
    if (req.method === "GET") {
      const { clientId } = req.query;
      if (!clientId) { context.res.status = 400; context.res.body = JSON.stringify({ error: "clientId required" }); return; }
      try {
        const { resource } = await clients.item(clientId, clientId).read();
        context.res.body = JSON.stringify({ list: resource?.employees || [] });
      } catch (e) {
        if (e.code === 404) { context.res.body = JSON.stringify({ list: [] }); }
        else throw e;
      }
      return;
    }
    if (req.method === "POST") {
      const { clientId, list } = req.body;
      if (!clientId) { context.res.status = 400; context.res.body = JSON.stringify({ error: "clientId required" }); return; }
      // Patch employees field onto existing client doc
      const { resource: existing } = await clients.item(clientId, clientId).read();
      await clients.items.upsert({ ...existing, employees: list || [] });
      context.res.body = JSON.stringify({ list: list || [] });
      return;
    }
    context.res.status = 405; context.res.body = JSON.stringify({ error: "Method not allowed" });
  } catch (e) {
    context.res.status = 500; context.res.body = JSON.stringify({ error: e.message });
  }
};
