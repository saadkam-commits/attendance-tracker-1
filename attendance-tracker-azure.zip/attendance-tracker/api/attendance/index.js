// api/attendance/index.js
// GET /api/attendance?clientId=X&monthKey=2025-03
// POST /api/attendance  { clientId, monthKey, records, updatedBy }
const { attendance } = require("../shared/cosmosClient");

module.exports = async function (context, req) {
  context.res = { headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } };

  try {
    if (req.method === "GET") {
      const { clientId, monthKey } = req.query;
      if (!clientId || !monthKey) { context.res.status = 400; context.res.body = JSON.stringify({ error: "clientId and monthKey required" }); return; }

      const docId = `${clientId}__${monthKey}`;
      try {
        const { resource } = await attendance.item(docId, docId).read();
        context.res.body = JSON.stringify(resource || { records: {} });
      } catch (e) {
        if (e.code === 404) { context.res.body = JSON.stringify({ records: {} }); }
        else throw e;
      }
      return;
    }

    if (req.method === "POST") {
      const { clientId, monthKey, records, updatedBy } = req.body;
      if (!clientId || !monthKey) { context.res.status = 400; context.res.body = JSON.stringify({ error: "clientId and monthKey required" }); return; }

      const docId = `${clientId}__${monthKey}`;
      const doc = { id: docId, clientId, monthKey, records: records || {}, updatedBy, updatedAt: new Date().toISOString() };
      await attendance.items.upsert(doc);
      context.res.body = JSON.stringify(doc);
      return;
    }

    context.res.status = 405; context.res.body = JSON.stringify({ error: "Method not allowed" });
  } catch (e) {
    context.res.status = 500; context.res.body = JSON.stringify({ error: e.message });
  }
};
