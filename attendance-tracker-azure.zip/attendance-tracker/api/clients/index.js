// api/clients/index.js
// Handles: POST /api/clients (create), GET /api/clients?code=XXXX (lookup by code)
const { clients, members } = require("../shared/cosmosClient");
const { v4: uuidv4 } = require("uuid");

function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

module.exports = async function (context, req) {
  context.res = { headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } };

  try {
    // GET — look up client by access code
    if (req.method === "GET") {
      const code = req.query.code?.toUpperCase();
      if (!code) { context.res.status = 400; context.res.body = JSON.stringify({ error: "Code required" }); return; }

      const { resources } = await clients.items.query({
        query: "SELECT * FROM c WHERE c.code = @code",
        parameters: [{ name: "@code", value: code }]
      }).fetchAll();

      if (!resources.length) { context.res.status = 404; context.res.body = JSON.stringify({ error: "Invalid access code" }); return; }
      context.res.body = JSON.stringify(resources[0]);
      return;
    }

    // POST — create new client workspace
    if (req.method === "POST") {
      const { name, adminName } = req.body;
      if (!name || !adminName) { context.res.status = 400; context.res.body = JSON.stringify({ error: "name and adminName required" }); return; }

      const code = generateCode();
      const id = uuidv4();
      const clientDoc = { id, name, code, adminName, createdAt: new Date().toISOString() };
      await clients.items.create(clientDoc);

      // Add admin as first member
      await members.items.create({
        id: uuidv4(), clientId: id, name: adminName,
        isAdmin: true, joinedAt: new Date().toISOString()
      });

      context.res.body = JSON.stringify(clientDoc);
      return;
    }

    context.res.status = 405; context.res.body = JSON.stringify({ error: "Method not allowed" });
  } catch (e) {
    context.res.status = 500; context.res.body = JSON.stringify({ error: e.message });
  }
};
