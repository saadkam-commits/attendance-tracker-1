// api/members/index.js
// GET  /api/members?clientId=X
// POST /api/members  { clientId, name }
// DELETE /api/members?clientId=X&memberId=Y
const { members } = require("../shared/cosmosClient");
const { v4: uuidv4 } = require("uuid");

module.exports = async function (context, req) {
  context.res = { headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" } };

  try {
    if (req.method === "GET") {
      const { clientId } = req.query;
      if (!clientId) { context.res.status = 400; context.res.body = JSON.stringify({ error: "clientId required" }); return; }

      const { resources } = await members.items.query({
        query: "SELECT * FROM c WHERE c.clientId = @clientId ORDER BY c.joinedAt ASC",
        parameters: [{ name: "@clientId", value: clientId }]
      }).fetchAll();
      context.res.body = JSON.stringify(resources);
      return;
    }

    if (req.method === "POST") {
      const { clientId, name, isAdmin } = req.body;
      if (!clientId || !name) { context.res.status = 400; context.res.body = JSON.stringify({ error: "clientId and name required" }); return; }

      // Check duplicate
      const { resources: existing } = await members.items.query({
        query: "SELECT * FROM c WHERE c.clientId = @clientId AND c.name = @name",
        parameters: [{ name: "@clientId", value: clientId }, { name: "@name", value: name }]
      }).fetchAll();
      if (existing.length) { context.res.body = JSON.stringify(existing[0]); return; }

      const member = { id: uuidv4(), clientId, name, isAdmin: isAdmin || false, joinedAt: new Date().toISOString() };
      await members.items.create(member);
      context.res.body = JSON.stringify(member);
      return;
    }

    if (req.method === "DELETE") {
      const { memberId } = req.query;
      if (!memberId) { context.res.status = 400; context.res.body = JSON.stringify({ error: "memberId required" }); return; }
      await members.item(memberId, memberId).delete();
      context.res.body = JSON.stringify({ deleted: true });
      return;
    }

    context.res.status = 405; context.res.body = JSON.stringify({ error: "Method not allowed" });
  } catch (e) {
    context.res.status = 500; context.res.body = JSON.stringify({ error: e.message });
  }
};
