// api/shared/cosmosClient.js
const { CosmosClient } = require("@azure/cosmos");

const client = new CosmosClient({
  endpoint: process.env.COSMOS_ENDPOINT,
  key: process.env.COSMOS_KEY,
});

const db = client.database("AttendanceDB");

module.exports = {
  clients:    db.container("clients"),
  attendance: db.container("attendance"),
  members:    db.container("members"),
};
